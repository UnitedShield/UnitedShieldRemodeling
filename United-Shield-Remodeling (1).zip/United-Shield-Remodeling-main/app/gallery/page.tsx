import type { Metadata } from "next"
import Header from "@/components/header"
import ServiceHero from "@/components/service-hero"
import BeforeAfterGallery from "@/components/before-after-gallery"
import CTASection from "@/components/cta-section"
import Footer from "@/components/footer"

export const metadata: Metadata = {
  title: "Project Gallery | United Shield Remodeling | The Woodlands, Spring, Conroe, Tomball, Montgomery, Magnolia, Willis, Cypress, and North Houston",
  description:
    "View our stunning before and after remodeling projects. Kitchen, bathroom, flooring & home addition transformations by United Shield Remodeling in The Woodlands, Spring, Conroe, Tomball, Montgomery, Magnolia, Willis, Cypress, and North Houston.",
  openGraph: {
    title: "Project Gallery | United Shield Remodeling | The Woodlands, Spring, Conroe, Tomball, Montgomery, Magnolia, Willis, Cypress, and North Houston",
    description:
      "View our stunning before and after remodeling projects. Kitchen, bathroom, flooring & home addition transformations.",
    images: [
      {
        url: "/images/usrm-banner.jpg",
        width: 1200,
        height: 630,
        alt: "United Shield Remodeling Kitchen Project",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Project Gallery | United Shield Remodeling",
    description: "View our stunning before and after remodeling projects in the The Woodlands, Spring, Conroe, Tomball, Montgomery, Magnolia, Willis, Cypress, and North Houston",
    images: ["/images/usrm-banner.jpg"],
  },
}

export default function GalleryPage() {
  return (
    <main className="min-h-screen">
      <Header />
      <ServiceHero
        title="See Our Work in Action"
        subtitle="Every project tells a story of transformation. Browse our gallery of completed remodeling projects and imagine what we can do for your home."
        backgroundImage="/images/usrm-banner.jpg"
      />
      <BeforeAfterGallery />
      <CTASection />
      <Footer />
    </main>
  )
}
